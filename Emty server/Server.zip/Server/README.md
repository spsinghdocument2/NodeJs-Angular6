# NgCourse

// require linux based system


navigate to project folder via terminal and after that

For start your node application
NODE_ENV=development node server.js




Api define in :-
urlmapping.js

:- Db model schema define in model folder
:- Controllers define in controller folder
:- Services define in service folder
:- configration settings in conf.js
:- port changes in bootstrap.js
:- database connection in Datasource.js  // now commented

 hit this Api :-(in postman)
localhost:3003/api/v1/userapi/fetchData



Thanks

Contact me : shashwat.company@gmail.com
Mob        : 8920832260