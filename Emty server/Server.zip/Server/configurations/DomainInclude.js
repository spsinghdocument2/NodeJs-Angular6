global.domain = {}

// domain.notifications = require("../application/models/Notifications.js")
// domain.video = require("../application/models/video.js")
// domain.course = require("../application/models/course.js")
// domain.event =require("../application/models/event.js")
domain.User = require("../application/models/user.js");
// domain.registrationToken =require("../application/models/registrationToken.js");



module.exports = domain
