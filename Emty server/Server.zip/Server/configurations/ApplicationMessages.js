		var appErrorMessages = {
		    failedLogin: "Sorry! Email or password do not match.",

		}

		var appSuccessMessage = {
		    alreadyRegister: "This user is already registered",

		}
		var NotificationSubject = {

		}
		var LoginMessage = {
		    registerFirst: "You are not yet registered. It only takes a few moments to register.",

		}
		var RoleAccessMessage = {
		    notRightAuthority: "You are not authorized to create user of this role user"
		}

		module.exports.LoginMessage = LoginMessage
		module.exports.appSuccessMessage = appSuccessMessage
		module.exports.appErrorMessages = appErrorMessages
		module.exports.NotificationSubject = NotificationSubject
		module.exports.RoleAccessMessage = RoleAccessMessage
