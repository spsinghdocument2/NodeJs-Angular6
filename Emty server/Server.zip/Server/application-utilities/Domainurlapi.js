module.exports.url ={
    feedurl:{
      api:"https://affiliate-api.flipkart.net/affiliate/api/",
      id:'roopaksma',
      token:'7dbb9e869b134e5b976d913fdb0fc778'
    },
    'facebookAuth' : {
    'clientID'      : '1047165451989921', // your App ID
    'clientSecret'  : '8ceb45ca382b162672b60e2c7c336480', // your App Secret
    'callbackURL'   : 'http://localhost:3000/auth/facebook/callback'
    },
};
