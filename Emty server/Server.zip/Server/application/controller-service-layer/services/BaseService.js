BaseService = function() {};

module.exports = BaseService;